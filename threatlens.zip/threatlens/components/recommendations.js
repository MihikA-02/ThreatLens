// components/recommendations.js

export function renderRecommendations(container, recs) {
  container.innerHTML = `
    <div class="section-title">
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      Recommendations
    </div>
    <div class="rec-list">
      ${(recs || []).map(r => `
        <div class="rec-item">
          <span class="rec-check">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
          </span>
          <span>${r.action}${r.reason ? `<span style="color:var(--color-text-muted);font-size:11px;display:block;margin-top:2px">${r.reason}</span>` : ''}</span>
        </div>
      `).join('')}
      ${!recs?.length ? '<div style="color:var(--color-text-muted);font-size:13px;padding:12px 0">No specific recommendations.</div>' : ''}
    </div>
  `;
}
