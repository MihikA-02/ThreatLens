// components/riskScore.js

import { animateNumber, animateCircle, getScoreColor, getScoreClass, getScoreBgClass } from '../js/utils/animate.js';

export function renderRiskScore(container, result) {
  const { riskScore, threatLevel, aiConfidence, summary, threatTags } = result;
  const color = getScoreColor(riskScore);
  const scoreClass = getScoreClass(riskScore);
  const badgeClass = getScoreBgClass(riskScore);

  const tagsHTML = (threatTags || []).map(tag => `
    <span class="threat-tag ${badgeClass}" style="font-size:12px">
      ${tag.name}
      <span class="tag-tooltip">${tag.tooltip || ''}</span>
    </span>
  `).join('');

  const now = new Date();
  const scanTime = now.toLocaleDateString('en-IN', { day:'numeric', month:'short', year:'numeric' })
    + ', ' + now.toLocaleTimeString('en-IN', { hour:'2-digit', minute:'2-digit', hour12:true });

  container.innerHTML = `
    <div class="risk-score-section card" style="position:relative; overflow:hidden;">
      <div class="risk-score-title">Overall Risk Score</div>
      <div class="risk-score-inner">
        <div class="risk-circle-wrap">
          <svg class="risk-circle-svg" viewBox="0 0 120 120">
            <circle class="risk-circle-track" cx="60" cy="60" r="52"/>
            <circle id="risk-fill" class="risk-circle-fill" cx="60" cy="60" r="52"
              style="stroke-dasharray:326; stroke-dashoffset:326; transition: stroke-dashoffset 1.2s cubic-bezier(0.4,0,0.2,1), stroke 0.5s ease;"/>
          </svg>
          <div class="risk-circle-label">
            <span id="risk-number" class="risk-number ${scoreClass}">0</span>
            <span class="risk-denom">/100</span>
          </div>
        </div>

        <div class="risk-meta">
          <div id="risk-level" class="risk-level ${scoreClass}">${threatLevel} Risk</div>
          <div class="risk-badge ${badgeClass}">
            ⚠ Threat Detected
          </div>
          <div class="risk-summary">${summary}</div>
          <div class="threat-tags-row">${tagsHTML}</div>
          <div class="scan-meta">
            <span>Scanned At: ${scanTime}</span>
            <span>AI Confidence: <span style="color:var(--color-safe);font-weight:700">${aiConfidence}%</span></span>
          </div>
        </div>
      </div>

      <!-- Hacker SVG decoration -->
      <div class="hacker-figure" style="position:absolute;right:16px;top:16px;width:80px;opacity:0.5;pointer-events:none">
        ${hackerSVG(color)}
      </div>
    </div>
  `;

  // Animate
  const fill = container.querySelector('#risk-fill');
  const numEl = container.querySelector('#risk-number');
  animateCircle(fill, riskScore, color);
  animateNumber(numEl, 0, riskScore, 1200);
}

function hackerSVG(color) {
  return `<svg viewBox="0 0 80 120" xmlns="http://www.w3.org/2000/svg">
    <defs><radialGradient id="hg" cx="50%" cy="30%" r="50%">
      <stop offset="0%" stop-color="${color}" stop-opacity="0.4"/>
      <stop offset="100%" stop-color="${color}" stop-opacity="0.05"/>
    </radialGradient></defs>
    <!-- Hood -->
    <path d="M40 10 C20 10 12 28 12 45 L12 90 L68 90 L68 45 C68 28 60 10 40 10Z" fill="url(#hg)"/>
    <path d="M40 10 C20 10 12 28 12 45 L12 90 L68 90 L68 45 C68 28 60 10 40 10Z" fill="none" stroke="${color}" stroke-width="1.5" opacity="0.5"/>
    <!-- Face shadow oval -->
    <ellipse cx="40" cy="42" rx="16" ry="18" fill="rgba(0,0,0,0.7)"/>
    <!-- Eyes glow -->
    <ellipse cx="34" cy="40" rx="3" ry="2" fill="${color}" opacity="0.9"/>
    <ellipse cx="46" cy="40" rx="3" ry="2" fill="${color}" opacity="0.9"/>
    <!-- Warning triangle -->
    <polygon points="40,100 30,115 50,115" fill="none" stroke="${color}" stroke-width="2"/>
    <line x1="40" y1="105" x2="40" y2="110" stroke="${color}" stroke-width="1.5"/>
    <circle cx="40" cy="112" r="1" fill="${color}"/>
  </svg>`;
}
