// js/modules/api.service.js – Calls Anthropic API

export async function analyzeContent({ type, value, imageBase64 }) {
  const userContent = buildPrompt(type, value, imageBase64);

  const systemPrompt = `You are ThreatLens, an expert AI cybersecurity analyst specializing in phishing, scams, and malicious content detection. 
Analyze the given content and return a JSON response ONLY (no markdown, no preamble, no extra text) with this exact structure:

{
  "riskScore": <0-100 integer>,
  "threatLevel": "<Safe|Low|Medium|High|Critical>",
  "aiConfidence": <60-99 integer>,
  "summary": "<2-3 sentence summary of the threat>",
  "threatTags": [{"name": "<tag>", "tooltip": "<1 sentence explanation>"}],
  "radarValues": {
    "Phishing": <0-100>,
    "Credential Theft": <0-100>,
    "Malicious URL": <0-100>,
    "Social Engineering": <0-100>,
    "Urgency": <0-100>,
    "Safe Signals": <0-100>
  },
  "threatsDetected": [
    {"name": "<threat name>", "severity": "<Critical|High|Medium|Low>", "description": "<short description>", "detail": "<expanded detail>"}
  ],
  "recommendations": [
    {"action": "<action>", "reason": "<why>", "priority": "<High|Medium|Low>"}
  ],
  "timeline": [
    {"time": "00:00", "title": "<step title>", "desc": "<short desc>", "detail": "<expanded detail>"}
  ]
}

Be accurate. Never invent threats that aren't there. If content is safe, return a low risk score with "Safe Signals" high.`;

  const messages = [{ role: 'user', content: userContent }];

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-6',
      max_tokens: 1500,
      system: systemPrompt,
      messages,
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new Error(err.error?.message || `API error ${response.status}`);
  }

  const data = await response.json();
  const text = data.content?.map(b => b.text || '').join('') || '';

  // Strip any accidental markdown fences
  const clean = text.replace(/```json|```/g, '').trim();
  return JSON.parse(clean);
}

function buildPrompt(type, value, imageBase64) {
  if (type === 'screenshot' && imageBase64) {
    return [
      { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: imageBase64 } },
      { type: 'text', text: 'Analyze this screenshot for phishing, scam, or malicious content.' },
    ];
  }

  const labels = { url: 'URL', email: 'Email', message: 'Message/Text' };
  return `Analyze this ${labels[type] || type} for threats:\n\n${value}`;
}
